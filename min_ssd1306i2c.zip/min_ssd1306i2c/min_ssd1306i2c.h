// Program : min_ssd1306i2c.h ( Arduino Library for SSD1306 I2C OLED Module 64x128 pixel )
// Relased Sept 2021 by TeakSoon Ding ( Malaysia )
// Tested on Arduino Uno with the Arduino 1.8.15 IDE Sofware
//
// min_ssd1306i2c library is designed to be small as possible. Many minor error 
// and boundry checks are not coded in order to keep the library small.
// It has a built-in 7x5 pixel font array ( 95 chars, ranged from ASCII char 32 to 126 ). 
// 
// This min_ssd1306i2c library have 5 main functions,
//
// 1. min_ssd1306_begin(); run this before using the other library display functions
// 
// 2. min_ssd1306_clearScreen();    // Clears the screen
// 3. min_ssd1306_showBitmap();     // Display a bitmap from an Array of 8-bits
// 4. min_ssd1306_showChar();       // Display a single char
// 5. min_ssd1306_showString();     // Display a string ( null terminated array of chars )
//
// This libary comes with three small example program, 
// 1. basic_demo.ino // display "Hello World" on the OLED screen
// 2. full_demo.ino // use all the main 5 functions
// 3. full_demo_avr.ino // same as full_demo.ino, uses pure C-language for smaller size
//
#ifndef MIN_SSD1306_LIBRARY_H

    #define MIN_SSD1306_LIBRARY_H

    #include <avr/io.h>
    #include <avr/pgmspace.h>

    #define min_ssd1306_ADDR_W              0x78
    #define min_ssd1306_ADDR_R              0x79
    #define min_ssd1306_SETCONTRAST         0x81
    #define min_ssd1306_DISPLAYALLON_RESUME 0xA4
    #define min_ssd1306_DISPLAYALLON        0xA5
    #define min_ssd1306_NORMALDISPLAY       0xA6
    #define min_ssd1306_INVERTDISPLAY       0xA7
    #define min_ssd1306_DISPLAYOFF          0xAE
    #define min_ssd1306_DISPLAYON           0xAF
    #define min_ssd1306_SETDISPLAYOFFSET    0xD3
    #define min_ssd1306_SETCOMPINS          0xDA
    #define min_ssd1306_SETVCOMDETECT       0xDB
    #define min_ssd1306_SETDISPLAYCLOCKDIV  0xD5
    #define min_ssd1306_SETPRECHARGE        0xD9
    #define min_ssd1306_SETMULTIPLEX        0xA8
    #define min_ssd1306_SETLOWCOLUMN        0x00
    #define min_ssd1306_SETHIGHCOLUMN       0x10
    #define min_ssd1306_SETSTARTLINE        0x40
    #define min_ssd1306_MEMORYMODE          0x20
    #define min_ssd1306_COLUMNADDR          0x21
    #define min_ssd1306_PAGEADDR            0x22
    #define min_ssd1306_COMSCANINC          0xC0
    #define min_ssd1306_COMSCANDEC          0xC8
    #define min_ssd1306_SEGREMAP            0xA1
    #define min_ssd1306_CHARGEPUMP          0x8D
    #define min_ssd1306_NOSCROLL            0x2E

    void _min_ssd1306_avrtwi_init();
    void _min_ssd1306_avrtwi_start(); 
    void _min_ssd1306_avrtwi_stop();
    void _min_ssd1306_avrtwi_write(char ch);
    char _min_ssd1306_avrtwi_read();
    void _min_ssd1306_startCommand();
    void _min_ssd1306_startData();
    void _min_ssd1306_setRow(char nn);
    void _min_ssd1306_setCol(char nn);
    void _min_ssd1306_char(char ch); 
    void min_ssd1306_clearScreen(); 
    void min_ssd1306_begin();
    void min_ssd1306_showChar(char row, char col, char ch);
    void min_ssd1306_showString(char row, char col, char str[]);
    void min_ssd1306_showBitmap(int row, int col, char bitmap[], int colLength);

#endif
