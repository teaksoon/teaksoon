// Program : min_ssd1306i2c.cpp ( Arduino Library for SSD1306 I2C OLED Module 64x128 pixel )
// Relased Sept 2021 by TeakSoon Ding ( Malaysia )
// - Tested on Arduino Uno with the Arduino 1.8.15 IDE Sofware
//
// min_ssd1306i2c library is designed to be small as possible. Many minor error 
// and boundry checks are not coded in order to keep the library small.
// It has a built-in 7x5 pixel font array ( 95 chars, ranged from ASCII char 32 to 126 ). 
// 
// This min_ssd1306i2c library have 5 main functions,
//
// 1. min_ssd1306_begin(); run this before using the other library display functions
// 
// 2. min_ssd1306_clearScreen();    // Clears the screen
// 3. min_ssd1306_showBitmap();     // Display a bitmap from an Array of 8-bits
// 4. min_ssd1306_showChar();       // Display a single char
// 5. min_ssd1306_showString();     // Display a string ( null terminated array of chars )
//
// This libary comes with three small example program, 
// 1. basic_demo.ino // display "Hello World" on the OLED screen
// 2. full_demo.ino // use all the main 5 functions
// 3. full_demo_avr.ino // same as full_demo.ino, uses pure C-language for smaller size
//

#include "min_ssd1306i2c.h"

const char font7x5[] PROGMEM = { 
 0b00000000,0b00000000,0b00000000,0b00000000,0b00000000,  /* space (ascii 32) */
 0b00000000,0b00000000,0b01011111,0b00000000,0b00000000,  /* ! */
 0b00000000,0b00000111,0b00000000,0b00000111,0b00000000,  /* " */
 0b00010100,0b01111111,0b00010100,0b01111111,0b00010100,  /* # */
 0b00100100,0b00101010,0b01111111,0b00101010,0b00010010,  /* $ */
 0b00100011,0b00010011,0b00001000,0b01100100,0b01100010,  /* % */
 0b00110110,0b01001001,0b01010101,0b00100010,0b01010000,  /* & */
 0b00000000,0b00000101,0b00000011,0b00000000,0b00000000,  /* ' */
 0b00000000,0b00011100,0b00100010,0b01000001,0b00000000,  /* ( */
 0b00000000,0b01000001,0b00100010,0b00011100,0b00000000,  /* ) */
 0b00010100,0b00001000,0b00111110,0b00001000,0b00010100,  /* * */
 0b00001000,0b00001000,0b00111110,0b00001000,0b00001000,  /* + */
 0b00000000,0b01010000,0b00110000,0b00000000,0b00000000,  /* , */
 0b00001000,0b00001000,0b00001000,0b00001000,0b00001000,  /* - */
 0b00000000,0b01100000,0b01100000,0b00000000,0b00000000,  /* .  */
 0b00100000,0b00010000,0b00001000,0b00000100,0b00000010,  /* / */
 0b00111110,0b01010001,0b01001001,0b01000101,0b00111110,  /* 0 (ascii 48) */
 0b00000000,0b01000010,0b01111111,0b01000000,0b00000000,  /* 1 */
 0b01000010,0b01100001,0b01010001,0b01001001,0b01000110,  /* 2 */
 0b00100001,0b01000001,0b01000101,0b01001011,0b00110001,  /* 3 */
 0b00011000,0b00010100,0b00010010,0b01111111,0b00010000,  /* 4 */
 0b00100111,0b01000101,0b01000101,0b01000101,0b00111001,  /* 5 */
 0b00111100,0b01001010,0b01001001,0b01001001,0b00110000,  /* 6 */
 0b00000001,0b01110001,0b00001001,0b00000101,0b00000011,  /* 7 */
 0b00110110,0b01001001,0b01001001,0b01001001,0b00110110,  /* 8 */
 0b00000110,0b01001001,0b01001001,0b00101001,0b00011110,  /* 9 (ascii 57) */
 0b00000000,0b00110110,0b00110110,0b00000000,0b00000000,  /* : */
 0b00000000,0b01010110,0b00110110,0b00000000,0b00000000,  /* ; */
 0b00001000,0b00010100,0b00100010,0b01000001,0b00000000,  /* < */
 0b00100100,0b00100100,0b00100100,0b00100100,0b00100100,  /* = */
 0b00000000,0b01000001,0b00100010,0b00010100,0b00001000,  /* > */
 0b00000010,0b00000001,0b01010001,0b00001001,0b00000110,  /* ?  */
 0b00110010,0b01001001,0b01111001,0b01000001,0b00111110,  /* @  */
 0b01111110,0b00001001,0b00001001,0b00001001,0b01111110,  /* A (ascii 65) */
 0b01111111,0b01001001,0b01001001,0b01001001,0b00110110,  /* B */
 0b00111110,0b01000001,0b01000001,0b01000001,0b00100010,  /* C */
 0b01111111,0b01000001,0b01000001,0b00100010,0b00011100,  /* D */
 0b01111111,0b01001001,0b01001001,0b01001001,0b01000001,  /* E */
 0b01111111,0b00001001,0b00001001,0b00001001,0b00000001,  /* F */
 0b00111110,0b01000001,0b01001001,0b01001001,0b01111010,  /* G */
 0b01111111,0b00001000,0b00001000,0b00001000,0b01111111,  /* H */
 0b00000000,0b01000001,0b01111111,0b01000001,0b00000000,  /* I */
 0b00100000,0b01000000,0b01000001,0b00111111,0b00000001,  /* J */
 0b01111111,0b00001000,0b00010100,0b00100010,0b01000001,  /* K */
 0b01111111,0b01000000,0b01000000,0b01000000,0b01000000,  /* L */
 0b01111111,0b00000010,0b00001100,0b00000010,0b01111111,  /* M */
 0b01111111,0b00000100,0b00001000,0b00010000,0b01111111,  /* N */
 0b00111110,0b01000001,0b01000001,0b01000001,0b00111110,  /* O */
 0b01111111,0b00001001,0b00001001,0b00001001,0b00000110,  /* P */
 0b00111110,0b01000001,0b01010001,0b00100001,0b01011110,  /* Q */
 0b01111111,0b00001001,0b00011001,0b00101001,0b01000110,  /* R */
 0b01000110,0b01001001,0b01001001,0b01001001,0b00110001,  /* S */
 0b00000001,0b00000001,0b01111111,0b00000001,0b00000001,  /* T */
 0b00111111,0b01000000,0b01000000,0b01000000,0b00111111,  /* U */ 
 0b00011111,0b00100000,0b01000000,0b00100000,0b00011111,  /* V */
 0b00111111,0b01000000,0b00111000,0b01000000,0b00111111,  /* W */
 0b01100011,0b00010100,0b00001000,0b00010100,0b01100011,  /* X */
 0b00000111,0b00001000,0b01110000,0b00001000,0b00000111,  /* Y */
 0b01100001,0b01010001,0b01001001,0b01000101,0b01000011,  /* Z */
 0b00000000,0b01111111,0b01000001,0b01000001,0b00000000,  /* [ */
 0b00000011,0b00000110,0b00011100,0b00110000,0b01100000,  /* backslash */
 0b00000000,0b01000001,0b01000001,0b01111111,0b00000000,  /* ] */
 0b00000100,0b00000010,0b00000001,0b00000010,0b00000100,  /* ^ */
 0b10000000,0b10000000,0b10000000,0b10000000,0b10000000,  /* _ */
 0b00000000,0b00000001,0b00000010,0b00000100,0b00000000,  /* ` */  
 0b00100000,0b01010100,0b01010100,0b01010100,0b01111000,  /* a (ascii 97) */
 0b01111111,0b01001000,0b01000100,0b01000100,0b00111000,  /* b */
 0b00111000,0b01000100,0b01000100,0b01000100,0b00100000,  /* c */
 0b00111000,0b01000100,0b01000100,0b01001000,0b01111111,  /* d */
 0b00111000,0b01010100,0b01010100,0b01010100,0b00011000,  /* e */
 0b00001000,0b01111110,0b00001001,0b00000001,0b00000010,  /* f */
 0b00001100,0b01010010,0b01010010,0b01010010,0b00111110,  /* g */
 0b01111111,0b00001000,0b00000100,0b00000100,0b01111000,  /* h */
 0b00000000,0b01000100,0b01111101,0b01000000,0b00000000,  /* i */
 0b00100000,0b01000000,0b01000100,0b00111101,0b00000000,  /* j */
 0b01111111,0b00010000,0b00101000,0b01000100,0b00000000,  /* k */
 0b00000000,0b00000001,0b01111111,0b01000000,0b00000000,  /* l */
 0b01111100,0b00000100,0b00011000,0b00000100,0b01111000,  /* m */
 0b01111100,0b00001000,0b00000100,0b00000100,0b01111000,  /* n */
 0b00111000,0b01000100,0b01000100,0b01000100,0b00111000,  /* o */
 0b01111100,0b00010100,0b00010100,0b00010100,0b00001000,  /* p */
 0b00001000,0b00010100,0b00010100,0b00011000,0b01111100,  /* q */
 0b01111100,0b00001000,0b00000100,0b00000100,0b00001000,  /* r */
 0b01001000,0b01010100,0b01010100,0b01010100,0b00100000,  /* s */
 0b00000100,0b00111111,0b01000100,0b01000000,0b00100000,  /* t */
 0b00111100,0b01000000,0b01000000,0b00100000,0b01111100,  /* u */
 0b00011100,0b00100000,0b01000000,0b00100000,0b00011100,  /* v */
 0b00111100,0b01000000,0b00110000,0b01000000,0b00111100,  /* w */
 0b01000100,0b00101000,0b00010000,0b00101000,0b01000100,  /* x */
 0b00001100,0b01010000,0b01010000,0b01010000,0b00111100,  /* y */
 0b01000100,0b01100100,0b01010100,0b01001100,0b01000100,  /* z (ascii 122) */
 0b00000000,0b00001000,0b00110110,0b01000001,0b00000000,  /* { */
 0b00000000,0b00000000,0b01111111,0b00000000,0b00000000,  /* | */
 0b00000000,0b01000001,0b00110110,0b00001000,0b00000000,  /* } */
 0b00010000,0b00001000,0b00001000,0b00010000,0b00001000   /* ~ (ascii 126) */
};

// AVR TWI library ( i2c interface )
//
void _min_ssd1306_avrtwi_init() {
  TWSR = 1;TWBR = 0x0C;TWCR = (1<<TWEN);
}
void _min_ssd1306_avrtwi_start() {
  TWCR = (1<<TWINT)|(1<<TWSTA)|(1<<TWEN);
  while ((TWCR & (1<<TWINT))==0){}
}
void _min_ssd1306_avrtwi_stop() {
  TWCR = (1<<TWINT)|(1<<TWSTO)|(1<<TWEN);
}
void _min_ssd1306_avrtwi_write(char ch) {
  TWDR = ch;
  TWCR = (1<<TWINT)|(1<<TWEN);
  while((TWCR & (1<<TWINT))==0){}
}
char _min_ssd1306_avrtwi_read() {
  TWCR = (1 << TWINT) | (1 << TWEN);
  while ((TWCR & (1 << TWINT)) == 0) {}
  return TWDR;
}

void _min_ssd1306_startCommand() {
  _min_ssd1306_avrtwi_start();
  _min_ssd1306_avrtwi_write(min_ssd1306_ADDR_W);
  _min_ssd1306_avrtwi_write(0x00); // Command
  // ... optional additional write after the command write
  // _min_ssd1306_avrtwi_stop(); // this is required to end command
}

void _min_ssd1306_startData() {
  _min_ssd1306_avrtwi_start();
  _min_ssd1306_avrtwi_write(min_ssd1306_ADDR_W);
  _min_ssd1306_avrtwi_write(min_ssd1306_SETSTARTLINE); // Data Command, Starting fr Page&Column
  // ...following write, write(1)=display, write(0)=clear
  // _min_ssd1306_avrtwi_stop(); // this is required to end data
}

void _min_ssd1306_setRow(char nn) { // 0 to 7
  _min_ssd1306_startCommand();
  _min_ssd1306_avrtwi_write(min_ssd1306_PAGEADDR);
  _min_ssd1306_avrtwi_write(nn);_min_ssd1306_avrtwi_write(7);
  _min_ssd1306_avrtwi_stop();
}

void _min_ssd1306_setCol(char nn) { // 0 to 127
  _min_ssd1306_startCommand();
  _min_ssd1306_avrtwi_write(min_ssd1306_COLUMNADDR);
  _min_ssd1306_avrtwi_write(nn);_min_ssd1306_avrtwi_write(127);
  _min_ssd1306_avrtwi_stop();
}

void _min_ssd1306_char(char ch) {
  _min_ssd1306_startData();
  for (int i=0; i<5; i++) { 
    // write 5 bytes from font file = 5pixel horizontal, 8 pixel vertical
    _min_ssd1306_avrtwi_write(pgm_read_byte(&font7x5[((ch-32)*5)+i])); 
  }
  _min_ssd1306_avrtwi_write(0); // write 1 extra byte for spacing
  _min_ssd1306_avrtwi_stop();
}

void min_ssd1306_clearScreen() {
  _min_ssd1306_setRow(0);_min_ssd1306_setCol(0); 
  _min_ssd1306_startData();
  for(int i=0; i<1024; i++) {
    _min_ssd1306_avrtwi_write(0);
  }
  _min_ssd1306_avrtwi_stop();
  _min_ssd1306_setRow(0);_min_ssd1306_setCol(0);
}

void min_ssd1306_begin() { 
char initData[]= { 
  min_ssd1306_DISPLAYOFF,
  min_ssd1306_SETDISPLAYCLOCKDIV,0x80,
  min_ssd1306_SETMULTIPLEX,0x3F,
  min_ssd1306_SETDISPLAYOFFSET,0x00,
  min_ssd1306_SETSTARTLINE,
  min_ssd1306_CHARGEPUMP,0x14,
  min_ssd1306_MEMORYMODE,0x00,
  min_ssd1306_SEGREMAP,
  min_ssd1306_COMSCANDEC,
  min_ssd1306_SETCOMPINS,0x12,
  min_ssd1306_SETCONTRAST,0xCF,
  min_ssd1306_SETPRECHARGE,0xF1,
  min_ssd1306_SETVCOMDETECT,0x40,
  min_ssd1306_DISPLAYALLON_RESUME,
  min_ssd1306_NORMALDISPLAY,
  min_ssd1306_NOSCROLL,
  min_ssd1306_DISPLAYON 
  };
  _min_ssd1306_avrtwi_init();
  for (int i=0; i<sizeof(initData); i++) { 
    _min_ssd1306_startCommand();
    _min_ssd1306_avrtwi_write(initData[i]);
    _min_ssd1306_avrtwi_stop();
  }
  min_ssd1306_clearScreen();
}

void min_ssd1306_showChar(char row, char col, char ch) {
  _min_ssd1306_setRow(row);_min_ssd1306_setCol(col);
  _min_ssd1306_char(ch);
}

void min_ssd1306_showString(char row, char col, char str[]) {
int idx = 0;
  _min_ssd1306_setRow(row);_min_ssd1306_setCol(col);
  while (str[idx] > 0) {
    _min_ssd1306_char(str[idx]);idx++;
  }
}

void min_ssd1306_showBitmap(int row, int col, char bitmap[], int colLength) {
  _min_ssd1306_setRow(row);_min_ssd1306_setCol(col);
  _min_ssd1306_startData();
  for (int i=0;i<colLength;i++) {
    _min_ssd1306_avrtwi_write(bitmap[i]);
  }
  _min_ssd1306_avrtwi_stop();
}
